
import json, os, datetime

def save_json(data, company, source):
    os.makedirs("output", exist_ok=True)
    filename = f"output/{company}_{source}_{datetime.date.today()}.json"
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"Saved {len(data)} reviews to {filename}")
