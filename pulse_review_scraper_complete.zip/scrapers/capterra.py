
import requests
from bs4 import BeautifulSoup
import dateparser

def scrape_capterra(company, start_date, end_date):
    reviews = []
    url = f"https://www.capterra.com/p/{company.lower().replace(' ', '-')}/reviews/"
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers, timeout=10)
    soup = BeautifulSoup(response.text, "html.parser")

    for block in soup.select("div.review"):
        date_text = block.select_one("time")
        review_date = dateparser.parse(date_text.text) if date_text else None
        if not review_date:
            continue

        reviews.append({
            "title": block.select_one("h3").get_text(strip=True) if block.select_one("h3") else "",
            "review": block.select_one("p").get_text(strip=True) if block.select_one("p") else "",
            "date": review_date.strftime("%Y-%m-%d"),
            "rating": block.select_one(".rating").get_text(strip=True) if block.select_one(".rating") else None
        })
    return reviews
